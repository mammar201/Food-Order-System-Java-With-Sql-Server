/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.raven.form;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author Ammar
 */
public class ConnectionAdapterClass implements SQL_ServerConnection_InterFace{
    
    
        //FOOD ITEM ARRAY LIST
        ArrayList<String> items_names = new ArrayList<String>();
        //PRICE ITEM ARRAY LIST
        ArrayList<String> items_price = new ArrayList<String>();
        ArrayList<String> user_ids = new ArrayList<String>();
        ArrayList<String> user_inventory_item = new ArrayList<String>();
        ArrayList<String> user_inventory_price = new ArrayList<String>();
        ArrayList<String> userids_history = new ArrayList<String>();
        ArrayList<String> usernames_history = new ArrayList<String>();
        ArrayList<String> check_out = new ArrayList<String>();
        ResultSet rs;

    @Override
    public void Connect(String DatabaseName,String username,String password,String Query) {
        
        
        String url="jdbc:sqlserver://DESKTOP-6910HV5;databaseName=Food;encrypt=true;trustServerCertificate=true";
           try {
            Connection connection=DriverManager.getConnection(url,username,password);
            System.out.println("Connect to Sql Server Sucessfully");
            Statement stat=connection.createStatement();
            //Query="Select * from Food_Items_And_Price";      
            this.rs=stat.executeQuery(Query);
            
            
           }
           catch(SQLException E){
               
               System.out.println("Check Sql Is Running");
           }
    }
    
}
