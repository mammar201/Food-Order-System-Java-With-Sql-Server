/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.raven.form;

import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JLabel;

/**
 *
 * @author Ammar
 */
public abstract class ItemDetail {
    
        public abstract void DisplayImage(JLabel label,int ImageIndex);
        public abstract void DisplayPrice(JLabel label,int ItemIndex);
        public abstract void DisplayItemName(JLabel label,int ItemIndex);
        public abstract void DisplayItemDescription(JLabel label,int ItemIndex);
        
        public void DeliveryFee(JLabel label){
            String Fees="150";
            label.setText(Fees);
        }
        public double GST(double price){
            double GST=(price*25)/100;
            return GST=price+GST;
        }
}

