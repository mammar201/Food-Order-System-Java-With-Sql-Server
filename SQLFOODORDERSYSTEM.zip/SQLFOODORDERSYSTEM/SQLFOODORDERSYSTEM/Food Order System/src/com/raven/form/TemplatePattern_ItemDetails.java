/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.raven.form;

import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JLabel;

/**
 *
 * @author Ammar
 */
public class TemplatePattern_ItemDetails extends ItemDetail {
    
    String location="C:\\Users\\dell\\Documents\\NetBeansProjects\\ui-dashboard-001\\src\\com\\raven\\icon\\";
    String[] Pictures_List={"zinger_burger","beef_burger","grilled_zingerburger","combo_zingerburger","big_mac","fries","pizza_fries","cole_slow","broast","anda"};
    String[] ItemsNames_List={"Zinger Burger","Beef Burger","Grilled Zinger Burger","Combo Zinger Burger","Big Mac","French Fries","Pizza Fries","ColeSlow","King Broast","Aanda Wala Burger"};
    String[] itemsprice_List={"1000","720","1120","1320","690","1200","600","100","50","400"};
    String[] Description_List={"Good","Good","Good","Good","Good","Good","Good","Good","Good","Mujha Andar Wala Burger"};
    @Override
    public void DisplayImage(JLabel label,int ImageIndex) {
        
        location=location+Pictures_List[ImageIndex]+".png";
        ImageIcon icon = new ImageIcon(location);
        Image img = icon.getImage();
        Image imgScale = img.getScaledInstance(label.getWidth(), label.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(imgScale);
        label.setIcon(scaledIcon);
    }

    @Override
    public void DisplayPrice(JLabel label,int ItemIndex) {
        label.setText(itemsprice_List[ItemIndex]);
    }

    @Override
    public void DisplayItemName(JLabel label,int ItemIndex) {
        label.setText(ItemsNames_List[ItemIndex]);
    }

    @Override
    public void DisplayItemDescription(JLabel label,int ItemIndex) {
       label.setText(Description_List[ItemIndex]);
    }


    
}
