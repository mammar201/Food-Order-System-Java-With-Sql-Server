package com.raven.form;
import com.raven.component.Card_button;
import static com.raven.form.PanelLoginAndRegister.get_username;
import static com.raven.form.PanelLoginAndRegister.txtEmail;
import com.raven.model.Model_Card;
import com.raven.model.StatusType;
import com.raven.swing.ScrollBar;
import java.awt.Color;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import static com.raven.main.Main.form1;
import com.raven.swing.Button;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;
import net.miginfocom.swing.MigLayout;

public class Form_Home extends javax.swing.JPanel  implements ActionListener{
    
    DefaultListModel dm=new DefaultListModel();
    String price;
    //CONNECTION SQL CLASS WITH ARRAY LIST
    ConnectionAdapterClass connectionSql=new ConnectionAdapterClass();
    ConnectionAdapterClass connectionSql1=new ConnectionAdapterClass();

    String[] nameArr = new String[connectionSql.items_names.size()];
    String[] user_inventory_items = new String[connectionSql.user_inventory_item.size()];
    String[] user_inventory_price = new String[connectionSql.user_inventory_price.size()];
    String[] price_converted = new String[connectionSql.items_price.size()];
    
    //String[] items={"Zinger Burger","Beef Burger","Grilled Zinger Burger","Combo Zinger Burger","Big Mac","French Fries","Pizza Fries","ColeSlow","King Broast","Aanda Wala Burger"};
    int[] items_price={1000,720,1120,1320,690,1200,600,1200,600,100,50,400};
    //public static String[] items_price_String={"1000","720","1120","1320","690","1200","600","100","50","400"};
    public  ArrayList<Integer> TotalPrice=new ArrayList<Integer>();
    Table_ForEachUser_SingletonPattern Create_EachUserTable=Table_ForEachUser_SingletonPattern.get_UserTableInstance();

    public static int Sum_TotalPrice=0;
    public String label_price;
    int[] Total_price_Array=new int[100];
    int index=0;
    public static String bool_total="False";
    String value;
    public static String activate_delete="False";
    ResultSet result_statement;
    String andawala_burger;
    int inv_index;
    String items_row_inventory;
    String price_row_inventory;
    public static String bool_check_out="True";
    //Card_button ob=new Card_button();


    

    public Form_Home() throws SQLException {

        
        connect_sql();
        initComponents();
        
        updateData();
        Create_EachUserTable.create_user_specific_table();


        jList1.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
        jList1.setVisibleRowCount(-1);
        jList1.setLayoutOrientation(JList.HORIZONTAL_WRAP);
        card2.setData(new Model_Card(new ImageIcon(getClass().getResource("/com/raven/icon/profit.png")), "30% OFF ", "ON FIRST ORDER GET CASH BACK", ""));
        card3.setData(new Model_Card(new ImageIcon(getClass().getResource("/com/raven/icon/profit.png")), "Welcome "+get_username, "ON FIRST ORDER GET 40% CASH BACK", ""));
        card_button2.setData(new Model_Card(new ImageIcon(getClass().getResource("/com/raven/icon/4.png")), "Add to Cart ", "", ""));
        card_button2.jButton1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                addtocart();
            }
        });
        
        //  add row table
        populate();
        
            //Card_button    
        
 
    }
    public void addtocart(){

        int i=0;
        //CONVERTING ARRAY LIST INTO ARRAY
        nameArr = connectionSql.items_names.toArray(nameArr);
        price_converted = connectionSql.items_price.toArray(price_converted);
        for(i=0;i<nameArr.length-1;i++){
            if(value==nameArr[i]){
                break;
            }
        }
        label_price=price_converted[i].toString();
        activate_delete="True";
        bool_total="True";
        if(value=="Aanda Wala Burger"){
                    playSound();
        }
        //CREATING USER CART DATA AND UPDATING IT
        Create_EachUserTable.insert_valuesintTable(get_username,value.toString(),label_price);
        try {
        update_userTableSql();

        } 
        catch (SQLException ex) {
            Logger.getLogger(Form_Home.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void playSound() {
    try {
        AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(new File("C:\\Users\\Ammar\\Documents\\NetBeansProjects\\java-ui-dashboard-001-main\\part 3\\ui-dashboard-001\\src\\com\\raven\\icon\\anda_wala_burger.wav").getAbsoluteFile());
        Clip clip = AudioSystem.getClip();
        clip.open(audioInputStream);
        clip.start();
    } catch(Exception e) {
        System.out.println("Error with playing sound.");
        e.printStackTrace();
    }
}
        public void populate(){
        dm.clear();
        dm.addElement(new ImagesList("Ammar",new ImageIcon("C:\\Users\\Ammar\\Documents\\NetBeansProjects\\FoodOrderSystem\\Images\\food1.jpg")));
        dm.addElement(new ImagesList("Bilal",new ImageIcon("C:\\Users\\Ammar\\Documents\\NetBeansProjects\\FoodOrderSystem\\Images\\food1.jpg")));
        dm.addElement(new ImagesList("Zain",new ImageIcon("C:\\Users\\Ammar\\Documents\\NetBeansProjects\\FoodOrderSystem\\Images\\food1.jpg")));
        dm.addElement(new ImagesList("Hassan",new ImageIcon("C:\\Users\\Ammar\\Documents\\NetBeansProjects\\FoodOrderSystem\\Images\\food1.jpg")));
        dm.addElement(new ImagesList("Kashif",new ImageIcon("C:\\Users\\Ammar\\Documents\\NetBeansProjects\\FoodOrderSystem\\Images\\food1.jpg")));
        jList1.setCellRenderer(new Renderer());
        jList1.setModel(dm);
    }
        public void connect_sql() throws SQLException{
        connectionSql1.Connect("master", "user", "123","create view Food as select * from Food_Items_And_Price");
        connectionSql1.Connect("master", "user", "123","Select * from Food");
        connectionSql.Connect("master", "user", "123","Select * from Food_Items_And_Price");
        result_statement=connectionSql.rs;
        while(result_statement.next()){
        connectionSql.items_names.add(result_statement.getString(1));
        connectionSql.items_price.add(result_statement.getString(2));
            }
        }
        public void updateData(){
            String Item;
            String Price;
            //CONVERTING ARRAY LIST INTO ARRAY
            nameArr = connectionSql.items_names.toArray(nameArr);
            price_converted = connectionSql.items_price.toArray(price_converted);


        for(int i=0;i<nameArr.length;i++){
 
            Item=nameArr[i];
            Price=price_converted[i];
            String[] Data={Item,Price};
            DefaultTableModel tblModel=(DefaultTableModel)jTable1.getModel();
            tblModel.addRow(Data);
        }

    }
        public void update_userTableSql() throws SQLException{


            String[] Data={items_row_inventory,price_row_inventory};
            form1.form1_tblModel=(DefaultTableModel)form1.jTable1.getModel();
            form1.form1_tblModel.addRow(Data);
           
        }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panel = new javax.swing.JLayeredPane();
        card2 = new com.raven.component.Card();
        card3 = new com.raven.component.Card();
        panelBorder1 = new com.raven.swing.PanelBorder();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jList1 = new javax.swing.JList<>();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        card_button2 = new com.raven.component.Card_button();

        setBackground(new java.awt.Color(255, 255, 255));

        panel.setLayout(new java.awt.GridLayout(1, 0, 10, 0));

        card2.setColor1(new java.awt.Color(255, 102, 0));
        card2.setColor2(new java.awt.Color(255, 153, 51));
        panel.add(card2);

        card3.setColor1(new java.awt.Color(255, 102, 0));
        card3.setColor2(new java.awt.Color(255, 153, 51));
        panel.add(card3);

        panelBorder1.setBackground(new java.awt.Color(255, 255, 255));

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/raven/icon/image.png"))); // NOI18N

        jLabel3.setText("0");

        jLabel4.setText("Delivery Fee :");

        jLabel5.setText("Item Name :");

        jLabel6.setText("0");

        jLabel7.setText("Price :");

        jLabel9.setText("Description");

        javax.swing.GroupLayout panelBorder1Layout = new javax.swing.GroupLayout(panelBorder1);
        panelBorder1.setLayout(panelBorder1Layout);
        panelBorder1Layout.setHorizontalGroup(
            panelBorder1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelBorder1Layout.createSequentialGroup()
                .addGap(60, 60, 60)
                .addGroup(panelBorder1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 262, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(panelBorder1Layout.createSequentialGroup()
                        .addGroup(panelBorder1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(53, 53, 53)
                        .addGroup(panelBorder1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panelBorder1Layout.setVerticalGroup(
            panelBorder1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelBorder1Layout.createSequentialGroup()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20)
                .addGroup(panelBorder1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jLabel8))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelBorder1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jLabel7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelBorder1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jLabel6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 148, Short.MAX_VALUE))
        );

        jLabel1.setFont(new java.awt.Font("sansserif", 0, 16)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(127, 127, 127));
        jLabel1.setText("SELECTION MENU");

        jList1.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jList1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jList1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jList1);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Items", "Price"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jTable1);

        card_button2.setColor1(new java.awt.Color(255, 102, 0));
        card_button2.setColor2(new java.awt.Color(255, 153, 51));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(panel, javax.swing.GroupLayout.DEFAULT_SIZE, 861, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 415, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(card_button2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 203, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(panelBorder1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(panel, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(13, 13, 13)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(16, 16, 16)
                        .addComponent(panelBorder1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(45, 45, 45)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 224, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(41, 41, 41)
                        .addComponent(card_button2, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void jList1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jList1MouseClicked
        // TODO add your handling code here:
        Object val=jList1.getSelectedValue();
        ImagesList is=(ImagesList)val;
        Object mName=is.getName();
       //CONVERTING ARRAY LIST INTO ARRAY
        nameArr = connectionSql.items_names.toArray(nameArr);
        price_converted = connectionSql.items_price.toArray(price_converted);

        int i=0;
        for(i=0;i<nameArr.length-1;i++){
            if(mName==nameArr[i]){
                break;
            }
        }
        label_price=price_converted[i].toString();
        //ADDING DATA USING TABLES
        bool_total="True";
    }//GEN-LAST:event_jList1MouseClicked

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        
          //playSound();
        DefaultTableModel tblmodell= (DefaultTableModel)jTable1.getModel();
        
          
        items_row_inventory=tblmodell.getValueAt(jTable1.getSelectedRow(),0).toString();
        price_row_inventory=tblmodell.getValueAt(jTable1.getSelectedRow(),1).toString();
        //System.out.println("ITEMS SELECTED "+items_row_inventory+price_row_inventory);
        
        
          
          
        int column = 0;
        int row = jTable1.getSelectedRow();
        this.value = jTable1.getModel().getValueAt(row, column).toString();
        
        //      TEMPLATE METHOD PATTERN   //
        andawala_burger=this.value;
        
        ItemDetail templatePattern_ItemDetails=new TemplatePattern_ItemDetails();
        templatePattern_ItemDetails.DisplayImage(jLabel2, row);
        
        templatePattern_ItemDetails.DisplayPrice(jLabel3, row);
        
        templatePattern_ItemDetails.DisplayItemName(jLabel8, row);

        templatePattern_ItemDetails.DisplayItemDescription(jLabel10, row);
        
        templatePattern_ItemDetails.DeliveryFee(jLabel6);
        
    }//GEN-LAST:event_jTable1MouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.raven.component.Card card2;
    private com.raven.component.Card card3;
    private com.raven.component.Card_button card_button2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    public javax.swing.JList<String> jList1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JLayeredPane panel;
    private com.raven.swing.PanelBorder panelBorder1;
    // End of variables declaration//GEN-END:variables

    @Override
    public void actionPerformed(ActionEvent e) {
        
        
        
       Card_button ob=new Card_button();
       ob.jButton1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                addtocart();
            }
        });
        
    }


}
