/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.raven.form;

import static com.raven.form.PanelLoginAndRegister.txtEmail;
import com.raven.swing.MyTextField;
import java.awt.TextField;

/**
 *
 * @author Ammar
 */
public class Null_ObjectPattern {
 
       public void CheckingNullValue(MyTextField nullvalue){
           
       //ask miss if neccessary that if we can do check data for null without using null object pattern and also does that work for methods too or only object
       if(nullvalue.getText().isEmpty()){
            
         System.out.println("Please Do not Enter Null Value");
       }else{
           
         System.out.println("Great");
       }
    }
}
