package com.raven.form;

import com.raven.main.Main;
import com.raven.swing.Button;
import com.raven.swing.MyPasswordField;
import com.raven.swing.MyTextField;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import net.miginfocom.swing.MigLayout;

public class PanelLoginAndRegister extends javax.swing.JLayeredPane {
    
    //LOGIN BACKEND DATA
    ConnectionAdapterClass connectionSql=new ConnectionAdapterClass();
    ResultSet result_statement;
    String Login_query_insert;
    public static String login_user_id;
    String[] User_idsArray = new String[connectionSql.user_ids.size()];
    public static String get_username;
    
    //REGISTER BACKEND DATA
    String query_insert;
    String user_id;
    String name;
    //THIS CLASS DATA
    static MyTextField txtEmail ;
    Null_ObjectPattern check_nullvalue=new Null_ObjectPattern();

    
    

    public PanelLoginAndRegister() {
        result_statement=connectionSql.rs;
        initComponents();
        initRegister();
        initLogin();
        login.setVisible(false);
        register.setVisible(true);
        

    }
    public void connect_sql() throws SQLException{
    connectionSql.Connect("Food", "user", "123",query_insert);
    result_statement=connectionSql.rs;
    }
    public void register_ids(){

        String q1="Insert into Register_ID_Password(id,name)values(";
        String q2=q1+"'"+user_id+"'";
        String q3=q2+",";
        String q4=q3+"'"+name+"'";
        String q5=q4+")";
        query_insert=q5;
        //System.out.println(query_insert);
        
     }
    public void fetch_alluserids() throws SQLException{
        
        //Runing query to get all ids
        connectionSql.Connect("Food", "user", "123","Select id from Register_ID_Password");
        result_statement=connectionSql.rs;

        User_idsArray = connectionSql.user_ids.toArray(User_idsArray);
        while(result_statement.next()){
            
           connectionSql.user_ids.add(result_statement.getString(1));
           //System.out.println(result_statement.getString(1));
        }
        User_idsArray = connectionSql.user_ids.toArray(User_idsArray);
    }
        public void Check_UserId() throws SQLException{
        //Conacatinating 
        login_user_id=txtEmail.getText();
        String q1="Select name from Register_ID_Password where id=";
        Login_query_insert=q1+login_user_id;
        //System.out.println(query_insert);        
        connectionSql.Connect("Food", "user", "123",Login_query_insert);
        result_statement=connectionSql.rs;
        while(result_statement.next()){
        get_username=result_statement.getString(1);
        //System.out.println("UserId "+login_user_id);
        }
        for(int i=0;i<User_idsArray.length;i++){
            
            if(connectionSql.user_ids.contains(login_user_id)){
                 System.out.println("ID Found");
                 JOptionPane.showMessageDialog(this,"WELCOME "+get_username);  
                 new Main().setVisible(true);
                 break;
            }
            else if(txtEmail.getText().isEmpty()){
                  JOptionPane.showMessageDialog(this,"You need to fill this text field");  
                 break;
            }
            else{
                JOptionPane.showMessageDialog(this,"ID not Found");  
                 break;
            }
        }
    }

    private void initRegister() {
        register.setLayout(new MigLayout("wrap", "push[center]push", "push[]25[]10[]10[]25[]push"));
        JLabel label = new JLabel("Create Account");
        label.setFont(new Font("sansserif", 1, 30));
        label.setForeground(new Color(7, 164, 121));
        register.add(label);
        MyTextField txtUser = new MyTextField();
        txtUser.setPrefixIcon(new ImageIcon(getClass().getResource("/com/raven/icon/user.png")));
        txtUser.setHint("User Name");
        register.add(txtUser, "w 60%");
        MyTextField txtEmail = new MyTextField();
        txtEmail.setPrefixIcon(new ImageIcon(getClass().getResource("/com/raven/icon/mail.png")));
        txtEmail.setHint("User Id");
        register.add(txtEmail, "w 60%");
        Button cmd = new Button();
        cmd.setBackground(new Color(7, 164, 121));
        cmd.setForeground(new Color(250, 250, 250));
        cmd.setText("SIGN UP");
        register.add(cmd, "w 40%, h 40");
        cmd.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
            user_id=txtEmail.getText();
            name=txtUser.getText();
            register_ids();
            try {
                connect_sql();
            } catch (SQLException ex) {
                System.out.println("Connection Error");
            }

            }
        });
        
    }

    private void initLogin() {
        login.setLayout(new MigLayout("wrap", "push[center]push", "push[]25[]10[]10[]25[]push"));
        JLabel label = new JLabel("Sign In");
        label.setFont(new Font("sansserif", 1, 30));
        label.setForeground(new Color(7, 164, 121));
        login.add(label);
        this.txtEmail = new MyTextField();
        txtEmail.setPrefixIcon(new ImageIcon(getClass().getResource("/com/raven/icon/mail.png")));
        txtEmail.setHint("User Id");
        login.add(txtEmail, "w 60%");

        Button cmd = new Button();
        cmd.setBackground(new Color(7, 164, 121));
        cmd.setForeground(new Color(250, 250, 250));
        cmd.setText("SIGN IN");
        login.add(cmd, "w 40%, h 40");
        cmd.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                
                check_nullvalue.CheckingNullValue(txtEmail);

                login_user_id=txtEmail.getText();
                System.out.println("login_user_id "+login_user_id);
            try {
            fetch_alluserids();
            Check_UserId();
        } catch (SQLException ex) {
            Logger.getLogger(PanelLoginAndRegister.class.getName()).log(Level.SEVERE, null, ex);
        }
            }
        });
    }

    public void showRegister(boolean show) {
        if (show) {
            register.setVisible(true);
            login.setVisible(false);
        } else {
            register.setVisible(false);
            login.setVisible(true);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        login = new javax.swing.JPanel();
        register = new javax.swing.JPanel();

        setLayout(new java.awt.CardLayout());

        login.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout loginLayout = new javax.swing.GroupLayout(login);
        login.setLayout(loginLayout);
        loginLayout.setHorizontalGroup(
            loginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 327, Short.MAX_VALUE)
        );
        loginLayout.setVerticalGroup(
            loginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        add(login, "card3");

        register.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout registerLayout = new javax.swing.GroupLayout(register);
        register.setLayout(registerLayout);
        registerLayout.setHorizontalGroup(
            registerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 327, Short.MAX_VALUE)
        );
        registerLayout.setVerticalGroup(
            registerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        add(register, "card2");
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel login;
    private javax.swing.JPanel register;
    // End of variables declaration//GEN-END:variables
}
