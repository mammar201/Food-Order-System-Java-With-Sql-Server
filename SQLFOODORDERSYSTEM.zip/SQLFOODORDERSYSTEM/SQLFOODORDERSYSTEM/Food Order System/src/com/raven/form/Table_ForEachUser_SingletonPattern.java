/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.raven.form;

import static com.raven.form.PanelLoginAndRegister.login_user_id;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Ammar
 */
 //extends LoginPage to get user id but is null check Create_Query void
public class Table_ForEachUser_SingletonPattern{
       
       //Creating Connection Sql Objects
       ConnectionAdapterClass connectionSql=new ConnectionAdapterClass();
       ResultSet result_statement;
       String create_tableQuery;
       String insert_tableQuery;



       
       //Creating Private Object
       private static Table_ForEachUser_SingletonPattern UserTableInstance = new Table_ForEachUser_SingletonPattern();
       //Creating Private Constructor
       private Table_ForEachUser_SingletonPattern(){}
       //Getting User Instance
       public static Table_ForEachUser_SingletonPattern get_UserTableInstance(){
           return UserTableInstance;
       }
       public void create_tableQuery(){
           
           //ASK MISS THAT EXTENDS GET NULL DATA OF user_id
           String q0="create table ";
           String q1=q0+"table_"+login_user_id;
           String q2=q1+"("+"user_id"+" int,name varchar(40),items varchar(50),price int)";
           create_tableQuery=q2;
           System.out.println(create_tableQuery);
       }
       
       public void connect_sql_createtableQuery() throws SQLException{
       connectionSql.Connect("Food", "user", "123",create_tableQuery);
       result_statement=connectionSql.rs;
       }
       public void create_user_specific_table() throws SQLException{
       create_tableQuery();
       connect_sql_createtableQuery();
       }
       
       
       public void insert_valuesintTable(String user_name,String item_Name,String price){
           String q1="Insert into table_"+login_user_id+"(user_id,name,items,price)values(";
           String q2=q1+"'"+login_user_id+"'"+",";
           String q3=q2+"'"+user_name+"'"+",";
           String q4=q3+"'"+item_Name+"'"+",";
           String q5=q4+"'"+price+"'"+")";
           insert_tableQuery=q5;
           System.out.println(insert_tableQuery);
           
           connectionSql.Connect("Food", "user", "123",insert_tableQuery);
           result_statement=connectionSql.rs;
       }


       
       
      
       
    
}
