/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.raven.form;

import javax.swing.Icon;

/**
 *
 * @author Ammar
 */
public class ImagesList {
    
    public String name;
    public Icon img;
    
    public ImagesList(String text,Icon icon){
        
        this.name=text;
        this.img=icon;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Icon getImg() {
        return img;
    }

    public void setImg(Icon img) {
        this.img = img;
    }
    
}
