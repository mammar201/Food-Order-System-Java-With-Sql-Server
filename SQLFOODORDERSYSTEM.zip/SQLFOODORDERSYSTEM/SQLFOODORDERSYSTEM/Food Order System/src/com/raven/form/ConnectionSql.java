/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.raven.form;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Ammar
 */
public class ConnectionSql {
public static void main(String[] args) {
        String url="jdbc:sqlserver://DESKTOP-6910HV5;databaseName=Food;encrypt=true;trustServerCertificate=true";
        String username="user";
        String password="123";
        //String url = "jdbc:sqlserver://localhost;instanceName=DESKTOP-6910HV5;databaseName="+"FoodOrdersystem"+";integratedSecurity = false;";
        //FOOD ITEM ARRAY LIST
        ArrayList<String> items_names = new ArrayList<String>();
        //PRICE ITEM ARRAY LIST
        ArrayList<String> items_price = new ArrayList<String>();
        //USER IDS AND NAMES FOR HISTORY
        ArrayList<String> user_ids = new ArrayList<String>();
        ArrayList<String> usernames = new ArrayList<String>();

        try {
            Connection connection=DriverManager.getConnection(url,username,password);
            System.out.println("connected");
            Statement stat=connection.createStatement();
            String query1="Select * from Food_Items_And_Price";      
            ResultSet rs=stat.executeQuery(query1);
            while(rs.next()){
                System.out.println(rs.getString(1)+rs.getString(2));
                items_names.add(rs.getString(1));
                items_price.add(rs.getString(2));

            }
            System.out.println(items_names.toString());
            System.out.println(items_price.toString());

        } catch (SQLException ex) {
            Logger.getLogger(ConnectionSql.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}